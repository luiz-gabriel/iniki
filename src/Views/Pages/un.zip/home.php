<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Iniki - Encurtador de link | Encurtador de url</title>
	<link rel="stylesheet" href="Views/Pages/css/home.css">
	<meta name="keywords" content="encurtador de link, gerador de link, encurtar link, links curtos, encurtador de url, gerar link pequeno, encurtar url">
	<meta name="description" content="Aumente a quantidiade de clicks no seu link utilizando nosso encurtador! Também temos a opção de você personalizar seu link.">
</head>
<body>


	<header class="container-fluid">
		<div class="row middle-md middle-lg around-lg">
			<div class="col-sm-12 col-2 center-sm center-md start-lg">

				<a href="home.html">
					<h1>Iniki.xyz</h1>
				</a>

			</div>

			<div class="col-2 center-md center-lg menu-desk">
				<nav class="nav-desk">
					<ul class="navbar">
						<li>
							<a href="https://iniki.xyz/">Home</a>
						</li>

						<li class="btn_sub">Serviços
							<ul class="submenu">
								<li>
									<a href="https://iniki.xyz/monitorar-link">Monitorar link</a>
								</li>

								<li>
									<a href="https://iniki.xyz/encurtador-de-link-personalizado">Encurtador de link personalizado</a>
								</li>

								<li>
									<a href="https://iniki.xyz/gerador-link-whatsapp">Gerador de link para whatsapp</a>
								</li>

								<li>
									<a href="https://iniki.xyz/gerador-de-senhas">Gerador de senhas</a>
								</li>
							</ul>
						</li>

						<li>
							<a href="https://iniki.xyz/contato">Contato</a>
						</li>
						<li>
							<a href="https://iniki.xyz/denunciar-link">Denunciar link</a>
						</li>
					</ul>
				</nav>
			</div>

			<div class="col-2 end-lg end-md">
				<select class="linguagem">
					<option>PT-BR</option>
				</select>
			</div>
		</div>

		<button type="button" class="btn-menu">
			<img src="Views/Pages/img/menu.svg" alt="botao_menu">
		</button>

		<nav class="nav-mobile">

				<ul class="navbar">

					<a href="home.html"><h1>Iniki.xyz</h1></a>
					<div class="col-2 end-lg end-md">
						<select>
							<option>PT-BR</option>
						</select>
					</div>

					<li>
						<a href="https://iniki.xyz/">Home</a>
					</li>

					<li>
						<a href="iniki.xyz/denunciar-link">Denunciar link</a>
					</li>

					<li>
						<a href="https://iniki.xyz/contato">Contato</a>
					</li>

					<li>
						<a href="https://iniki.xyz/monitorar-link">Monitorar link</a>
					</li>

					<li>
						<a href="https://iniki.xyz/encurtador-de-link-personalizado">Encurtador de link personalizado</a>
					</li>

					<li>
						<a href="https://iniki.xyz/gerador-link-whatsapp">Gerador de link para whatsapp</a>
					</li>

					<li>
						<a href="https://iniki.xyz/gerador-de-senhas">Gerador de senhas</a>
					</li>

					<button type="button" class="btn-close">Fechar</button>

					<p>Todos os direitos reservados à Iniki.xyz</p>

				</ul>
			</nav>
	</header>

	<!-- BANNER -->
	<section class="banner">
		<h1>Encurte seus links de forma fácil, rápida e gratuita!</h1>
		<p>Seus visitantes vão agradecer por usar nosso redirecionador, ele é extremamente rápido! Então encurte de forma gratuita conosco e veja a quantidade de visitantes crescer! Se quiser um link encurtado de forma personalizada só <a href="/encurtador-de-link-personalizado">clicar aqui</a>.</p>
	</section>

	<!-- ECURTADOR -->
	<section class="container-fluid encurtador">

		<div class="row center-sm center-md center-lg">
			<div class="col-12 center-sm center-md center-lg">
				<h2>Encurte seu link agora!</h2>
			</div>

			<div class="col-sm-12 col-8 center-sm">
				<form method="post" class="input">
						<input type="text" name="url">
						<button type="submit" name="acao" class="btn">Encurte</button><br>
				</form>
				
			</div>
			<div class="form">
			</div>
		</div>

	</section>

	<!-- CARDS -->
	<section class="cards">

		<div class="row center-sm top-md top-lg around-md around-lg">
			<div class="col-sm-8 col-3">
				<div class="card ssl">
					<img src="Views/Pages/img/ssl.svg" alt="Cadeado">
					<h4>CERTIFICADO SSL</h4>
					<p>Mais segurança no transporte de informações e mais velocidade!</p>
				</div>
			</div>

			<div class="col-sm-8 col-3 pc">
				<div class="card">
					<img src="Views/Pages/img/pc.svg" alt="Computador">
					<h4>VELOCIDADE MÁXIMA</h4>
					<p>Utilizamos ssd nvme em todo o sistema, isso garante um redirecionamento rápido! Seus visitantes vão amar serem redirecionados para seu site, blog, perfil de reder social de forma muito rápida!</p>
				</div>
			</div>

			<div class="col-sm-8 col-3 link">
				<div class="card">
					<img src="Views/Pages/img/input.svg" alt="Bara de link">
					<h4>CONFIAVEL</h4>
					<p>Sempre procuramos links maliciosos encurtados, se encontramos excluiremos imediatamente! Nós ajude denunciando links maliciosos!</p>
				</div>
			</div>
		</div>

	</section>

	<!-- FINALIZAÇÂO -->
	<section class="container-fluid final">

		<div class="row center-sm middle-md middle-lg">

			<div class="col-sm-10 center-lg col-6">
				<img src="Views/Pages/img/gangorra.svg" alt="gangora">
			</div>

			<div class="col-sm-10 col-6 collumn">
				<h2>Você precisa atrair visitantes ou cliente para a sua loja? Podemos te ajudar!</h2>

				<h3>Não assuste seus clientes com links enormes e com caracteres estranhos, utilize o nosso encurtador de link. Use nosso encurtador de links, você pode <a href="/encurtador-de-link-personalizado">encurtar e personalizar o seu link</a>. Isso vai ser ótimo para posts em blogs, redes sociais. Venha fazer mais com iniki.xyz.</h3>
			</div>
		</div>

	</section>

	<!-- FOOTER -->
	<footer class="container-fluid">

		<div class="row center-sm middle-md middle-lg between-lg between-md">
			<div class="col-sm-12 col-3 center-sm">
				<a href="home.html"><h1>Iniki.xyz</h1></a>
			</div>

			<div class="col-sm-7 col-3 center-sm">
				<ul>

			<li>
				<a href="/home">Home</a>
			</li>
			<li>
				<a href="/monitorar-link">Monitorar link</a>
			</li>

			<li>
				<a href="/contato">Contato</a>
			</li>

			<li>
				<a href="/denunciar-link">Denunciar link</a>
			</li>

				</ul>
			</div>

			<div class="col-sm-7 col-2 center-sm">
				<ul>

					<li><a href="/encurtador-de-link-personalizado">Encurtador de link personalizado</a></li>
					<li><a href="/gerador-link-whatsapp">Gerador de link para whatsapp</a></li>
					<li><a href="/gerador-de-senhas">Gerador de senhas</a></li>

				</ul>
			</div>

			<div class="col-sm-12 col-3 center-sm">
				<p>Todos os direitos resevados à Iniki.xyz</p>
			</div>
		</div>

	</footer>

	<!-- Scripts -->
	<script src="js/menu_mobile.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-178631782-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-178631782-1');
	</script>
</body>
</html>
